# HwaFlow patch — install guide

This folder is a **drop-in patch** for your `HwaFlow-main` repo. It adds four
API routes, one server-side client, and one optional UI panel. It does **not**
change any existing table, RLS policy, page, or component behaviour, so your
current OCR → translate → proofread pipeline keeps working exactly as before.

---

## 1. Copy the files

From the root of your HwaFlow repo:

```bash
cp -r xian-scan-bridge/hwaflow-patch/lib/engine.ts                 lib/engine.ts
cp -r xian-scan-bridge/hwaflow-patch/app/api/engine                app/api/engine
cp -r xian-scan-bridge/hwaflow-patch/components/chapters/engine-panel.tsx \
      components/chapters/engine-panel.tsx
cp    xian-scan-bridge/hwaflow-patch/supabase/migrations/20261026130000_engine_purge.sql \
      supabase/migrations/20261026130000_engine_purge.sql
```

Result:

```
lib/engine.ts
app/api/engine/jobs/route.ts
app/api/engine/jobs/[id]/route.ts
app/api/engine/jobs/[id]/approve/route.ts
app/api/engine/jobs/[id]/reject/route.ts
app/api/engine/jobs/[id]/[kind]/[page]/route.ts
components/chapters/engine-panel.tsx
supabase/migrations/20261026130000_engine_purge.sql   (optional)
```

No new npm packages. `server-only` and `@supabase/ssr` are already dependencies.
Run `supabase db push` once to apply the optional migration.

---

## 2. Add the environment variables

`.env.local` (and the same in Cloudflare → Workers & Pages → your HwaFlow
project → Settings → Environment variables, marked **Secret/Encrypted**):

```dotenv
ENGINE_API_URL=https://engine.hwaflow.space
ENGINE_WEB_TOKEN=<the SAME random string as the Worker's WEB_TOKEN secret>
ENGINE_PURGE_SUPABASE_ORIGINALS=1   # optional; see below
```

`ENGINE_WEB_TOKEN` is **never** exposed to the browser — no `NEXT_PUBLIC_`
prefix, ever. It's only read inside `lib/engine.ts`, which is `server-only`.

`ENGINE_PURGE_SUPABASE_ORIGINALS` is **off by default**. Turn it on only after
applying the optional migration. It makes the engine's Approve button also
delete the user's original WebPs from the Supabase `pages` bucket and mark
those `chapter_pages` rows `purged` — implementing the `purge_on_approval`
policy your docs already promise. Leave it off if you want to keep originals in
Supabase (the R2 raw copies are always deleted regardless).

All three names are already appended (blank) to `.env.example` in
`HwaFlow-with-engine.zip`.

---

## 2b. Automatic Kaggle start (the "kernel push" mode)

This patch does **not** need to change for auto-start. Two additions are
already in place:

- `app/api/engine/jobs/route.ts` reads `text_blocks.final_text` and sends it as
  `translations[page][block]` in the job metadata. **This is only an offline
  fallback.** The primary translator is XianScan's own
  `GeminiTranslationProvider` running inside the Kaggle kernel
  (`KAGGLE_TRANSLATION_MODE=gemini`). The user rejected the older HwaFlow
  Gemini output as unreliable, so it is never used when the kernel has
  internet + a Gemini key.
- `lib/engine.ts` forwards it and exposes `EngineJob.kaggle` — a small status
  object (`queued → uploading → dataset_pending → running → complete`) so the
  existing poll loop can show what Kaggle is doing.

Everything else is in `xian-scan-bridge/kaggle/README.md`. If the Worker has
no `KAGGLE_USERNAME`/`KAGGLE_KEY`, it behaves exactly like the older pull
bridge and `EngineJob.kaggle` is `null` — no code path breaks.

> **`engine.hwaflow.space` is a proposed subdomain.** Replace it with your
> real Worker hostname if Cloudflare gave you a `*.workers.dev` URL instead.

---

## 3. Mount the panel (optional but recommended)

In `components/chapters/workspace-view.tsx`:

```tsx
// near the other ./components/chapters imports
import { EnginePanel } from "./engine-panel";
```

Then insert it just **after** the closing `</div>` of `<div className="ch-header">`
and immediately before `{uploadErrors.length > 0 ? (`:

```tsx
              </div>   {/* end ch-header */}

              <EnginePanel chapterId={chapter.id} canApprove={canManage} />

              {uploadErrors.length > 0 ? (
```

Use `canManage` (not `canApprove`) — `canApprove` in this file is narrower
(`canManage && status === "submitted"`) and would hide the image Approve button
while a chapter is still `ready`. `onApproved` is optional; leave it out if you
want image approval and chapter approval to stay as two separate clicks.

> If you don't want to touch the workspace yet, you can test the whole backend
> with curl (step 5) and mount the panel afterwards.

---

## 4. How it plugs into what you already have

| Already in HwaFlow | What the patch does |
| --- | --- |
| `chapter_pages.original_path` → Supabase Storage `pages` bucket | `POST /api/engine/jobs` reads those originals and forwards them to the bridge |
| `series.source_language` (`ko`/`ja`/`zh`) | Mapped to engine OCR codes (`ko`/`ja`/`zh-Hans`) |
| `glossary_terms` (active terms, per series) | Forwarded into the CLI's `--glossary` so names stay consistent |
| `requirePipelineViewer()` session + rate-limit gate | Reused for every new engine route |
| `storage_state` + `groups.retention_policy` (documented, unimplemented) | Optional migration + `ENGINE_PURGE_SUPABASE_ORIGINALS=1` finally implements purge-on-approval in Supabase too |

Nothing here writes to your `text_blocks` table. If you later want the engine's
`regions.json` (OCR boxes + source/target text) to appear in your bubble
editor, read `GET /api/engine/jobs/:id/regions/:page` and feed it into
`setPanelBlocksAction` — the shapes are already compatible (`bbox`,
`sourceText`/`textSource`, `textTarget`). That is a phase-2, ~30-line change.

---

## 5. Test without touching the UI

```bash
# start the site
npm run dev

# create a job for a chapter that already has uploaded panels
curl -X POST http://localhost:3000/api/engine/jobs \
  -H 'content-type: application/json' \
  -H "cookie: <your session cookie>" \
  -d '{"chapterId":"<a real chapter uuid>"}'
# -> {"jobId":"...","status":"pending","pageCount":N}

curl -H "cookie: <your session cookie>" \
  http://localhost:3000/api/engine/jobs/<jobId>
# -> {"status":"done","urls":[...]} once the bridge finishes

curl -X POST -H "cookie: <your session cookie>" \
  http://localhost:3000/api/engine/jobs/<jobId>/approve
# -> {"status":"approved"} and the raw images are gone
```

---

## 6. Role check (recommended)

`approve/route.ts` currently uses the same signed-in + rate-limited gate as the
rest of the pipeline routes. If only Owners/Managers should approve the final
images, add your existing `canManage`-style check there:

```ts
// after `const auth = await requirePipelineViewer();`
// const allowed = await canManageChapter(auth.viewer, chapterId);
// if (!allowed) return Response.json({ error: "forbidden" }, { status: 403 });
```

`workspace-view.tsx` already hides the button for non-managers via
`canApprove`; the server check closes the direct-URL hole.
